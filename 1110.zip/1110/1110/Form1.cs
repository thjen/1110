﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1110
{
    public partial class Form1 : Form
    {
        private List<Thuoc> list = new List<Thuoc>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbMaHang.Text != "" && tbTenHang.Text != "")
                {
                    Thuoc thuoc = new Thuoc();
                    thuoc.MaHang = tbMaHang.Text;
                    thuoc.TenHang = tbTenHang.Text;
                    thuoc.NhaSanXuat = cbNhaSanXuat.Text;
                    thuoc.HanSuDung = Convert.ToDateTime(dtpHanSuDung.Text);
                    if (rbKhangSinh.Checked)
                        thuoc.NhomThuoc = "Kháng sinh";
                    if (rbThucPhamChucNang.Checked)
                        thuoc.NhomThuoc = "Thực phẩm chức năng";
                    if (rbThuocDacTri.Checked)
                        thuoc.NhomThuoc = "Thuốc đặc trị";
                    list.Add(thuoc);
                    LoadList();
                    Clear();
                }
                else throw new Exception("Nhập thiếu");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadList();
        }

        private void LoadList()
        {
            listThuoc.Items.Clear();
            foreach (var thuoc in list)
            {
                ListViewItem item = new ListViewItem(thuoc.MaHang);
                item.SubItems.Add(thuoc.TenHang);
                item.SubItems.Add(thuoc.NhaSanXuat);
                item.SubItems.Add(thuoc.NhomThuoc);
                item.SubItems.Add(thuoc.HanSuDung + "");
                listThuoc.Items.Add(item);
            }
        }

        private void Clear()
        {
            tbMaHang.Focus();
            tbMaHang.Text = "";
            tbTenHang.Text = "";
            cbNhaSanXuat.Text = "";
        }

        // sua
        private void button1_Click(object sender, EventArgs e)
        {
            Thuoc thuoc = null;
            int index = 0;
            foreach (Thuoc t in list)
            {
                if (t.MaHang == tbMaHang.Text) {
                    thuoc = t;
                    index++;
                }
            }
            if (thuoc == null) { MessageBox.Show("Không tồn tại mã hàng!"); return; };
            list[index].MaHang = tbMaHang.Text;
            list[index].TenHang = tbTenHang.Text;
            list[index].NhaSanXuat = cbNhaSanXuat.Text;
            list[index].HanSuDung = Convert.ToDateTime(dtpHanSuDung.Text);
            if (rbKhangSinh.Checked)
                list[index].NhomThuoc = "Kháng sinh";
            if (rbThucPhamChucNang.Checked)
                list[index].NhomThuoc = "Thực phẩm chức năng";
            if (rbThuocDacTri.Checked)
                list[index].NhomThuoc = "Thuốc đặc trị";
            LoadList();
            Clear();
        }

        // xoa
        private void button2_Click(object sender, EventArgs e)
        {
            Thuoc thuoc = null;
            foreach (Thuoc t in list)
            {
                if (t.MaHang == tbMaHang.Text) thuoc = t;
            }
            if (thuoc == null) { MessageBox.Show("Không tồn tại mã hàng!"); return; };
            list.Remove(thuoc);
            LoadList();
            Clear();
        }

        // quit
        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void listThuoc_MouseClick(object sender, MouseEventArgs e)
        {
            string maHang = (sender as ListView).FocusedItem.Text;
            //var thuoc = list.FirstOrDefault(el => el.MaHang == maHang);            
            Thuoc thuoc = null;
            foreach (Thuoc t in list)
                if (t.MaHang == maHang) thuoc = t;
            if (thuoc == null) return;
            tbMaHang.Text = thuoc.MaHang;
            tbTenHang.Text = thuoc.TenHang;
            cbNhaSanXuat.Text = thuoc.NhaSanXuat;
            dtpHanSuDung.Value = Convert.ToDateTime(thuoc.HanSuDung);
            if (thuoc.NhomThuoc == "Kháng sinh") rbKhangSinh.Checked = true;
            if (thuoc.NhomThuoc == "Thực phẩm chức năng") rbThucPhamChucNang.Checked = true;
            if (thuoc.NhomThuoc == "Thuốc đặc trị") rbThuocDacTri.Checked = true;
        }

        private void btSend_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(list);
            this.Hide();
            form2.ShowDialog();
        }
    }
}
